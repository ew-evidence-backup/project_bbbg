<?php
/**
 * @Author Evin Weissenberg
 */ ?>

<div id="footer">
    <div class="container">
        <p class="text-muted">Place sticky footer content here.</p>
    </div>
</div>